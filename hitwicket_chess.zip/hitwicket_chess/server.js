const http = require('http');
const WebSocket = require('ws');
const express = require('express');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let gameState = {
    board: Array(5).fill(null).map(() => Array(5).fill(null)),
    players: {
        A: { turn: true, pieces: {} },
        B: { turn: false, pieces: {} }
    },
    gameOver: false
};

// Deploy initial pieces for both players
function deployInitialPieces() {
    // Player A
    gameState.board[0] = ['A-P1', 'A-H1', 'A-H2', 'A-H1', 'A-P1'];
    gameState.players.A.pieces = {
        'A-P1': { x: 0, y: 0 },
        'A-H1': { x: 0, y: 1 },
        'A-H2': { x: 0, y: 2 },
        'A-H1': { x: 0, y: 3 },
        'A-P1': { x: 0, y: 4 },
    };

    // Player B
    gameState.board[4] = ['B-P1', 'B-H1', 'B-H2', 'B-H1', 'B-P1'];
    gameState.players.B.pieces = {
        'B-P1': { x: 4, y: 0 },
        'B-H1': { x: 4, y: 1 },
        'B-H2': { x: 4, y: 2 },
        'B-H1': { x: 4, y: 3 },
        'B-P1': { x: 4, y: 4 },
    };
}

deployInitialPieces();

// Function to switch turns between players
function switchTurns() {
    gameState.players.A.turn = !gameState.players.A.turn;
    gameState.players.B.turn = !gameState.players.B.turn;
}

// Function to check if the game is over
function checkGameOver() {
    const aPieces = Object.keys(gameState.players.A.pieces);
    const bPieces = Object.keys(gameState.players.B.pieces);

    if (aPieces.length === 0) {
        gameState.gameOver = true;
        return 'Player B';
    } else if (bPieces.length === 0) {
        gameState.gameOver = true;
        return 'Player A';
    }
    return null;
}

// Function to handle moves
function handleMove(player, move) {
    const [char, direction] = move.split(':');
    const currentPlayer = gameState.players[player];

    if (!currentPlayer.turn) {
        return { type: 'invalid', reason: 'Not your turn' };
    }

    const piece = currentPlayer.pieces[char];
    if (!piece) {
        return { type: 'invalid', reason: 'Invalid piece' };
    }

    let newX = piece.x;
    let newY = piece.y;

    switch (direction) {
        case 'L':
            newY -= 1;
            break;
        case 'R':
            newY += 1;
            break;
        case 'F':
            newX -= 1;
            break;
        case 'B':
            newX += 1;
            break;
        case 'FL':
            newX -= 2;
            newY -= 2;
            break;
        case 'FR':
            newX -= 2;
            newY += 2;
            break;
        case 'BL':
            newX += 2;
            newY -= 2;
            break;
        case 'BR':
            newX += 2;
            newY += 2;
            break;
        default:
            return { type: 'invalid', reason: 'Invalid move' };
    }

    if (newX < 0 || newX >= 5 || newY < 0 || newY >= 5) {
        return { type: 'invalid', reason: 'Out of bounds' };
    }

    const targetCell = gameState.board[newX][newY];

    if (targetCell && targetCell.startsWith(player)) {
        return { type: 'invalid', reason: 'Cannot capture your own piece' };
    }

    if (targetCell) {
        const opponent = player === 'A' ? 'B' : 'A';
        delete gameState.players[opponent].pieces[targetCell];
    }

    gameState.board[piece.x][piece.y] = null;
    gameState.board[newX][newY] = char;

    piece.x = newX;
    piece.y = newY;

    switchTurns();

    const winner = checkGameOver();

    return winner
        ? { type: 'game-over', winner }
        : { type: 'update', state: gameState };
}

// Handle WebSocket connections
wss.on('connection', (ws) => {
    ws.send(JSON.stringify({ type: 'init', state: gameState }));

    ws.on('message', (message) => {
        const data = JSON.parse(message);

        if (data.type === 'move') {
            const result = handleMove(data.player, data.move);
            wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify(result));
                }
            });
        }
    });
});

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

server.listen(8080, () => {
    console.log('Server is listening on http://localhost:8080');
});
