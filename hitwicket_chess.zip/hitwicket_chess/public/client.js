const ws = new WebSocket('ws://localhost:8080');

let selectedPiece = null;
let player = 'A'; // Assume player A for this example

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === 'init' || data.type === 'update') {
        updateGameBoard(data.state);
    } else if (data.type === 'invalid') {
        alert('Invalid move: ' + data.reason);
    } else if (data.type === 'game-over') {
        alert('Game Over! Winner: ' + data.winner);
        // Optionally reload the game
        window.location.reload();
    }
};

// Function to update the game board based on the current state
function updateGameBoard(state) {
    const board = document.getElementById('game-board');
    board.innerHTML = ''; // Clear the board

    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 5; j++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            const piece = state.board[i][j];

            if (piece) {
                cell.textContent = piece;
                cell.style.backgroundColor = piece.startsWith('A') ? '#ADD8E6' : '#FFB6C1'; // Light Blue for Player A, Light Pink for Player B
            }

            cell.addEventListener('click', () => onCellClick(i, j, piece));
            board.appendChild(cell);
        }
    }

    // Show current player's turn
    const controls = document.getElementById('controls');
    controls.innerHTML = `Current Turn: Player ${state.players.A.turn ? 'A' : 'B'}`;
}

// Handle cell clicks for selecting and moving pieces
function onCellClick(x, y, piece) {
    if (selectedPiece) {
        // Attempt to move the selected piece
        const move = getMoveDirection(selectedPiece, x, y);
        if (move) {
            ws.send(JSON.stringify({ type: 'move', player, move }));
        }
        selectedPiece = null; // Deselect the piece after the move
    } else if (piece && piece.startsWith(player)) {
        // Select the piece if it's the player's turn
        selectedPiece = piece;
    }
}

// Determine the move direction based on selected piece and target coordinates
function getMoveDirection(piece, targetX, targetY) {
    const currentX = parseInt(piece[2]);
    const currentY = parseInt(piece[3]);

    const deltaX = targetX - currentX;
    const deltaY = targetY - currentY;

    if (piece.includes('P')) { // Pawn moves
        if (deltaX === 1 && deltaY === 0) return `${piece}:F`;
        if (deltaX === -1 && deltaY === 0) return `${piece}:B`;
        if (deltaX === 0 && deltaY === 1) return `${piece}:R`;
        if (deltaX === 0 && deltaY === -1) return `${piece}:L`;
    }

    if (piece.includes('H1')) { // Hero1 moves
        if (deltaX === 2 && deltaY === 0) return `${piece}:F`;
        if (deltaX === -2 && deltaY === 0) return `${piece}:B`;
        if (deltaX === 0 && deltaY === 2) return `${piece}:R`;
        if (deltaX === 0 && deltaY === -2) return `${piece}:L`;
    }

    if (piece.includes('H2')) { // Hero2 moves
        if (deltaX === 2 && deltaY === 2) return `${piece}:FR`;
        if (deltaX === 2 && deltaY === -2) return `${piece}:FL`;
        if (deltaX === -2 && deltaY === 2) return `${piece}:BR`;
        if (deltaX === -2 && deltaY === -2) return `${piece}:BL`;
    }

    return null;
}
